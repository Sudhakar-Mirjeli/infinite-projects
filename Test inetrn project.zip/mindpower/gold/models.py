from django.db import models
from datetime import datetime
# Create your models here.
# 
class hitech(models.Model):
    title=models.CharField(max_length=100)
    description=models.TextField()
    author=models.CharField(max_length=100)
    created_at=models.DateTimeField(default=datetime.now)
    def _str_(Self):
        return Self.title