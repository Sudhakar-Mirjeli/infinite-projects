from django.apps import AppConfig


class GoldConfig(AppConfig):
    name = 'gold'
