from operator import concat
from django.shortcuts import render
from django.http import HttpResponse
from .models import hitech

# Create your views here.

def home(request):
    Post=hitech.objects.all()
    return render(request,"base.html",{'Post':Post})

def add(request):
    if request.method=='POST':
        name=request.POST['name']
        description=request.POST['description']
        author=request.POST['author']

        s=hitech(name=name,description=description,author=author)
        s.save()
    return render(request,"base.html")